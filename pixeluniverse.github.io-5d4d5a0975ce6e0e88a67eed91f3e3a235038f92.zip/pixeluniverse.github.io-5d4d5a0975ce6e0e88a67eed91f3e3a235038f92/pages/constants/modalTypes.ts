enum ModalTypes {
  NONE,
  INFOS,
  PROBLEM,
  CONVERTER,
  PARAMETERS,
  CAPTCHA,
  OVERLAY,
  BOOKMARKS,
  CANVASES,
  MODERATION,
};

export default ModalTypes;