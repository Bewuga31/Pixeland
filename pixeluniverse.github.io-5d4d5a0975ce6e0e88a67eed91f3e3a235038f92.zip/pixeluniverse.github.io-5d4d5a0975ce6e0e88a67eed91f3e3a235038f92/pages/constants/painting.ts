export const CHUNK_SIZE = 256;
export const PIXEL_SIZE = 50;